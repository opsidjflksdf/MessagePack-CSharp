﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using MessagePack;
using System.IO;
using TestNewMessagePack;

namespace TestNewMessagePack
{

public class A1
{
    public int a1;
}

[MessagePackObject( keyAsPropertyName: true )]
public class TestMpTemplatesGeneric<T>
{
    public T t;
}

[MessagePackObject( keyAsPropertyName: true )]
public class TestMpTemplatesContainer
{
    public TestMpTemplatesGeneric<A1> a;
}

}

public class Script1 : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
    	Debug.Log( "Start" );
 		MyMain();       
    }

    // Update is called once per frame
    void Update()
    {
        
    }

	public static void MyMain()
    {
		MessagePack.Resolvers.StaticCompositeResolver.Instance.Register(
		    // use generated resolver first, and combine many other 
		    //generated/custom resolvers
		    MessagePack.Resolvers.TestNewResolver.Instance,

		    // finally, use builtin/primitive resolver (don't use StandardResolver, 
		    //it includes dynamic generation)
		    MessagePack.Resolvers.BuiltinResolver.Instance,
		    MessagePack.Resolvers.AttributeFormatterResolver.Instance,
		    MessagePack.Resolvers.PrimitiveObjectResolver.Instance
		);

		MessagePack.MessagePackSerializer.DefaultOptions = new 
		    MessagePack.MessagePackSerializerOptions( 
		        MessagePack.Resolvers.StaticCompositeResolver.Instance );

		string folderPath = @"C:\UnityMessagePackOutput\";

		{

		    TestMpTemplatesGeneric<A1> obIn = new TestMpTemplatesGeneric<A1>()
		    {
		        t = new A1{ a1 = 3, },
		    };

			string binaryFilePath = $@"{folderPath}MessagePack.plain_generic.out";

		    using (FileStream streamOut = 
		        File.Open(binaryFilePath, FileMode.Create ))
		    {
		        MessagePackSerializer.Serialize( streamOut, obIn);
		    }

		    TestMpTemplatesGeneric<A1> obOut;

		    using (FileStream streamIn = 
		        File.Open(binaryFilePath, FileMode.Open ))
		    {
		        obOut = MessagePackSerializer.Deserialize<
		            TestMpTemplatesGeneric<A1>>( streamIn );    
		    }

		    string textFilePath = $@"{folderPath}MessagePack.plain_generic_value.txt";

		    using ( StreamWriter writer = File.CreateText( textFilePath ))
		    {
		        writer.Write( $"Value out: obGeneric.t.a1 = " +
		       		$"{obOut.t.a1}" );
		    }
		}

		//or, in a container:
		{
		    TestMpTemplatesContainer obIn = new TestMpTemplatesContainer()
		    {
		        a = new TestMpTemplatesGeneric<A1>{ t = new A1{ a1 = 7, }, }
		    };

		    string binaryFilePath = $@"{folderPath}MessagePack.container.out";
		    using (FileStream streamOut = 
		        File.Open(binaryFilePath, FileMode.Create ))
		    {
		        MessagePackSerializer.Serialize( streamOut, obIn );
		    }

		    TestMpTemplatesContainer obOut;

		    using (FileStream streamIn = 
		        File.Open(binaryFilePath, FileMode.Open ))
		    {
		        obOut = MessagePackSerializer.Deserialize<
		            TestMpTemplatesContainer>( streamIn );
		    }

		    string textFilePath = $@"{folderPath}MessagePack.container_value.txt";

		    using ( StreamWriter writer = File.CreateText( textFilePath ))
		    {
		        writer.Write( $"Value out: container.a.t.a1 = " +
		       		$"{obOut.a.t.a1}" );
		    }
		}

	}
}
